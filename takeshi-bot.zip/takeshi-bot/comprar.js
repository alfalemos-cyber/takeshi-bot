const MercadoPagoService = require('../mercadopago');
const fs = require('fs');
const path = require('path');

// Planos disponíveis
const PLANOS = {
    '1': { nome: 'Plano Básico', preco: 20.00, duracao: '30 dias', descricao: 'Acesso VPN por 30 dias' },
    '2': { nome: 'Plano Premium', preco: 35.00, duracao: '60 dias', descricao: 'Acesso VPN por 60 dias' },
    '3': { nome: 'Plano Ultra', preco: 50.00, duracao: '90 dias', descricao: 'Acesso VPN por 90 dias' }
};

exports.run = async (sock, message, args) => {
    const chatId = message.key.remoteJid;
    const userId = message.key.participant || message.key.remoteJid;
    
    try {
        // Se não há argumentos, mostrar planos disponíveis
        if (!args[0]) {
            let menuText = "🛒 *PLANOS DISPONÍVEIS* 🛒\n\n";
            
            Object.keys(PLANOS).forEach(key => {
                const plano = PLANOS[key];
                menuText += `*${key}.* ${plano.nome}\n`;
                menuText += `💰 Preço: R$ ${plano.preco.toFixed(2)}\n`;
                menuText += `⏰ Duração: ${plano.duracao}\n`;
                menuText += `📝 ${plano.descricao}\n\n`;
            });
            
            menuText += "Para comprar, digite: */comprar [número do plano]*\n";
            menuText += "Exemplo: */comprar 1*";
            
            await sock.sendMessage(chatId, { text: menuText });
            return;
        }

        const planoEscolhido = args[0];
        
        if (!PLANOS[planoEscolhido]) {
            await sock.sendMessage(chatId, { 
                text: "❌ Plano inválido! Use */comprar* para ver os planos disponíveis." 
            });
            return;
        }

        const plano = PLANOS[planoEscolhido];
        const mercadoPago = new MercadoPagoService();
        
        // Gerar referência única para o pagamento
        const externalReference = `vpn_${userId.replace('@s.whatsapp.net', '')}_${Date.now()}`;
        
        // Criar pagamento PIX
        const pagamento = await mercadoPago.createPixPayment(
            plano.preco,
            `${plano.nome} - ${plano.descricao}`,
            externalReference
        );

        if (!pagamento.success) {
            await sock.sendMessage(chatId, { 
                text: "❌ Erro ao gerar pagamento. Tente novamente mais tarde." 
            });
            return;
        }

        // Salvar informações do pedido
        const pedidoData = {
            userId: userId,
            chatId: chatId,
            plano: plano,
            paymentId: pagamento.payment_id,
            externalReference: externalReference,
            status: 'pending',
            createdAt: new Date().toISOString()
        };

        // Salvar no arquivo de pedidos
        const pedidosFile = path.join(__dirname, '..', '..', 'database', 'pedidos.json');
        let pedidos = [];
        
        if (fs.existsSync(pedidosFile)) {
            pedidos = JSON.parse(fs.readFileSync(pedidosFile, 'utf8'));
        }
        
        pedidos.push(pedidoData);
        
        // Criar diretório se não existir
        const dbDir = path.dirname(pedidosFile);
        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true });
        }
        
        fs.writeFileSync(pedidosFile, JSON.stringify(pedidos, null, 2));

        // Enviar informações do pagamento
        let mensagemPagamento = `🛒 *PEDIDO CRIADO COM SUCESSO!* 🛒\n\n`;
        mensagemPagamento += `📦 *Plano:* ${plano.nome}\n`;
        mensagemPagamento += `💰 *Valor:* R$ ${plano.preco.toFixed(2)}\n`;
        mensagemPagamento += `⏰ *Duração:* ${plano.duracao}\n\n`;
        mensagemPagamento += `🔢 *ID do Pagamento:* ${pagamento.payment_id}\n\n`;
        mensagemPagamento += `📱 *PIX Copia e Cola:*\n\`\`\`${pagamento.qr_code}\`\`\`\n\n`;
        mensagemPagamento += `⚠️ *Importante:*\n`;
        mensagemPagamento += `• O pagamento expira em 30 minutos\n`;
        mensagemPagamento += `• Após o pagamento, seu login será enviado automaticamente\n`;
        mensagemPagamento += `• Use o comando */status ${pagamento.payment_id}* para verificar o pagamento`;

        await sock.sendMessage(chatId, { text: mensagemPagamento });

        // Iniciar verificação automática do pagamento
        setTimeout(() => {
            verificarPagamento(sock, pagamento.payment_id, chatId, plano);
        }, 30000); // Verificar após 30 segundos

    } catch (error) {
        console.error('Erro no comando comprar:', error);
        await sock.sendMessage(chatId, { 
            text: "❌ Erro interno. Tente novamente mais tarde." 
        });
    }
};

// Função para verificar pagamento automaticamente
async function verificarPagamento(sock, paymentId, chatId, plano) {
    const mercadoPago = new MercadoPagoService();
    
    try {
        const status = await mercadoPago.checkPaymentStatus(paymentId);
        
        if (status.success && status.status === 'approved') {
            // Pagamento aprovado - criar usuário VPN
            await criarUsuarioVPN(sock, chatId, plano, paymentId);
        } else if (status.success && status.status === 'pending') {
            // Ainda pendente - verificar novamente em 1 minuto
            setTimeout(() => {
                verificarPagamento(sock, paymentId, chatId, plano);
            }, 60000);
        }
    } catch (error) {
        console.error('Erro ao verificar pagamento:', error);
    }
}

// Função para criar usuário VPN
async function criarUsuarioVPN(sock, chatId, plano, paymentId) {
    const VPNManager = require('../vpn-manager');
    const vpnManager = new VPNManager();
    
    try {
        await sock.sendMessage(chatId, { 
            text: `✅ *PAGAMENTO APROVADO!*\n\n🔄 Criando seu acesso VPN...` 
        });

        // Gerar credenciais
        const username = vpnManager.generateUsername('vpn');
        const password = vpnManager.generatePassword(10);
        
        // Calcular dias baseado no plano
        let days = 30;
        if (plano.duracao.includes('60')) days = 60;
        if (plano.duracao.includes('90')) days = 90;

        // Criar usuário SSH
        const userResult = await vpnManager.createSSHUser(username, password, days);
        
        if (userResult.created) {
            // Obter configuração completa
            const config = await vpnManager.createVPNConfig(username, password, plano);
            
            // Montar mensagem com as informações de acesso
            let mensagemLogin = `🎉 *ACESSO VPN CRIADO COM SUCESSO!* 🎉\n\n`;
            mensagemLogin += `📦 *Plano:* ${plano.nome}\n`;
            mensagemLogin += `⏰ *Válido até:* ${userResult.expirationDate}\n\n`;
            mensagemLogin += `🔐 *DADOS DE ACESSO:*\n`;
            mensagemLogin += `👤 *Usuário:* ${username}\n`;
            mensagemLogin += `🔑 *Senha:* ${password}\n`;
            mensagemLogin += `🌐 *Servidor:* ${config.servidor.ip}\n`;
            mensagemLogin += `🔌 *Porta SSH:* ${config.servidor.porta_ssh}\n\n`;
            
            mensagemLogin += `📱 *CONFIGURAÇÃO PARA APPS:*\n\n`;
            mensagemLogin += `*HTTP Injector:*\n`;
            mensagemLogin += `• Payload: \`${config.aplicativos.http_injector.payload}\`\n`;
            mensagemLogin += `• Proxy: \`${config.aplicativos.http_injector.proxy}\`\n\n`;
            
            mensagemLogin += `*HTTP Custom:*\n`;
            mensagemLogin += `• Payload: \`${config.aplicativos.http_custom.payload}\`\n`;
            mensagemLogin += `• Proxy: \`${config.aplicativos.http_custom.proxy}\`\n\n`;
            
            mensagemLogin += `*SSH Tunnel:*\n`;
            mensagemLogin += `• Host: \`${config.aplicativos.ssh_tunnel.host}\`\n`;
            mensagemLogin += `• Porta: \`${config.aplicativos.ssh_tunnel.porta}\`\n`;
            mensagemLogin += `• Usuário: \`${config.aplicativos.ssh_tunnel.usuario}\`\n`;
            mensagemLogin += `• Senha: \`${config.aplicativos.ssh_tunnel.senha}\`\n\n`;
            
            mensagemLogin += `⚠️ *IMPORTANTE:*\n`;
            mensagemLogin += `• Guarde bem essas informações\n`;
            mensagemLogin += `• Não compartilhe seus dados de acesso\n`;
            mensagemLogin += `• Em caso de dúvidas, entre em contato\n\n`;
            mensagemLogin += `✅ *Seu acesso está ativo e pronto para uso!*`;

            await sock.sendMessage(chatId, { text: mensagemLogin });
            
            // Atualizar status do pedido
            const fs = require('fs');
            const path = require('path');
            const pedidosFile = path.join(__dirname, '..', '..', 'database', 'pedidos.json');
            
            if (fs.existsSync(pedidosFile)) {
                let pedidos = JSON.parse(fs.readFileSync(pedidosFile, 'utf8'));
                const pedidoIndex = pedidos.findIndex(p => p.paymentId === paymentId);
                
                if (pedidoIndex !== -1) {
                    pedidos[pedidoIndex].status = 'completed';
                    pedidos[pedidoIndex].vpnUser = {
                        username: username,
                        password: password,
                        expirationDate: userResult.expirationDate,
                        config: config
                    };
                    pedidos[pedidoIndex].completedAt = new Date().toISOString();
                    
                    fs.writeFileSync(pedidosFile, JSON.stringify(pedidos, null, 2));
                }
            }
            
        } else {
            throw new Error('Falha ao criar usuário SSH');
        }
        
    } catch (error) {
        console.error('Erro ao criar usuário VPN:', error);
        await sock.sendMessage(chatId, { 
            text: `❌ *ERRO AO CRIAR ACESSO VPN*\n\nOcorreu um erro ao criar seu acesso. Entre em contato para resolvermos o problema.\n\n*ID do Pagamento:* ${paymentId}` 
        });
    }
}

exports.help = {
    name: "comprar",
    description: "Comprar planos VPN",
    usage: "comprar [número do plano]"
};

