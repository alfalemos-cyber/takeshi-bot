/**
 * Arquivo pra rodar alguns testes,
 * nada demais.
 *
 * @author Dev Gui
 */
(async () => {})();
