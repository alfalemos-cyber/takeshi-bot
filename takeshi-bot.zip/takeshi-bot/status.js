const MercadoPagoService = require('../mercadopago');

exports.run = async (sock, message, args) => {
    const chatId = message.key.remoteJid;
    
    try {
        if (!args[0]) {
            await sock.sendMessage(chatId, { 
                text: "❌ Informe o ID do pagamento!\nUso: */status [ID do pagamento]*" 
            });
            return;
        }

        const paymentId = args[0];
        const mercadoPago = new MercadoPagoService();
        
        await sock.sendMessage(chatId, { 
            text: "🔍 Verificando status do pagamento..." 
        });

        const status = await mercadoPago.checkPaymentStatus(paymentId);

        if (!status.success) {
            await sock.sendMessage(chatId, { 
                text: "❌ Erro ao verificar pagamento. Verifique se o ID está correto." 
            });
            return;
        }

        let statusText = `📊 *STATUS DO PAGAMENTO* 📊\n\n`;
        statusText += `🔢 *ID:* ${paymentId}\n`;
        statusText += `💰 *Valor:* R$ ${status.transaction_amount?.toFixed(2) || 'N/A'}\n`;
        
        // Traduzir status para português
        let statusPt = '';
        let emoji = '';
        
        switch (status.status) {
            case 'pending':
                statusPt = 'Pendente';
                emoji = '⏳';
                break;
            case 'approved':
                statusPt = 'Aprovado';
                emoji = '✅';
                break;
            case 'rejected':
                statusPt = 'Rejeitado';
                emoji = '❌';
                break;
            case 'cancelled':
                statusPt = 'Cancelado';
                emoji = '🚫';
                break;
            case 'refunded':
                statusPt = 'Reembolsado';
                emoji = '💸';
                break;
            default:
                statusPt = status.status;
                emoji = '❓';
        }
        
        statusText += `${emoji} *Status:* ${statusPt}\n`;
        
        if (status.external_reference) {
            statusText += `📝 *Referência:* ${status.external_reference}\n`;
        }

        if (status.status === 'pending') {
            statusText += `\n⚠️ *Aguardando pagamento...*\n`;
            statusText += `O status será atualizado automaticamente após a confirmação.`;
        } else if (status.status === 'approved') {
            statusText += `\n🎉 *Pagamento confirmado!*\n`;
            statusText += `Seu login VPN será enviado em instantes.`;
        } else if (status.status === 'rejected') {
            statusText += `\n❌ *Pagamento rejeitado.*\n`;
            statusText += `Entre em contato para mais informações.`;
        }

        await sock.sendMessage(chatId, { text: statusText });

    } catch (error) {
        console.error('Erro no comando status:', error);
        await sock.sendMessage(chatId, { 
            text: "❌ Erro interno. Tente novamente mais tarde." 
        });
    }
};

exports.help = {
    name: "status",
    description: "Verificar status do pagamento",
    usage: "status [ID do pagamento]"
};

