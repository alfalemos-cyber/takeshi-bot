const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class VPNManager {
    constructor() {
        this.sshPlusPath = '/root/ssh-plus'; // Caminho padrão do SSH-PLUS
        this.usersFile = '/root/usuarios.txt'; // Arquivo de usuários
    }

    // Gerar nome de usuário único
    generateUsername(prefix = 'vpn') {
        const timestamp = Date.now().toString().slice(-6);
        const random = crypto.randomBytes(3).toString('hex');
        return `${prefix}${timestamp}${random}`;
    }

    // Gerar senha aleatória
    generatePassword(length = 8) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let password = '';
        for (let i = 0; i < length; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    }

    // Criar usuário SSH
    async createSSHUser(username, password, days = 30) {
        return new Promise((resolve, reject) => {
            // Comando para criar usuário SSH com expiração
            const expirationDate = new Date();
            expirationDate.setDate(expirationDate.getDate() + days);
            const expDate = expirationDate.toISOString().split('T')[0];

            const commands = [
                `useradd -M -s /bin/false ${username}`,
                `echo "${username}:${password}" | chpasswd`,
                `chage -E ${expDate} ${username}`,
                `echo "${username} ${password} ${expDate}" >> ${this.usersFile}`
            ].join(' && ');

            exec(commands, (error, stdout, stderr) => {
                if (error) {
                    console.error('Erro ao criar usuário SSH:', error);
                    reject(error);
                    return;
                }
                
                resolve({
                    username,
                    password,
                    expirationDate: expDate,
                    created: true
                });
            });
        });
    }

    // Obter informações do servidor
    async getServerInfo() {
        return new Promise((resolve, reject) => {
            exec('hostname -I | awk \'{print $1}\'', (error, stdout, stderr) => {
                if (error) {
                    reject(error);
                    return;
                }
                
                const serverIP = stdout.trim();
                
                // Verificar portas SSH disponíveis
                exec('netstat -tlnp | grep :22', (error, stdout, stderr) => {
                    const sshPort = '22'; // Porta padrão SSH
                    
                    resolve({
                        ip: serverIP,
                        sshPort: sshPort,
                        hostname: 'VPN Server'
                    });
                });
            });
        });
    }

    // Verificar se usuário existe
    async userExists(username) {
        return new Promise((resolve) => {
            exec(`id ${username}`, (error) => {
                resolve(!error);
            });
        });
    }

    // Remover usuário
    async removeUser(username) {
        return new Promise((resolve, reject) => {
            const commands = [
                `userdel ${username}`,
                `sed -i "/${username}/d" ${this.usersFile}`
            ].join(' && ');

            exec(commands, (error, stdout, stderr) => {
                if (error) {
                    console.error('Erro ao remover usuário:', error);
                    reject(error);
                    return;
                }
                
                resolve({ removed: true });
            });
        });
    }

    // Listar usuários ativos
    async listActiveUsers() {
        return new Promise((resolve, reject) => {
            if (!fs.existsSync(this.usersFile)) {
                resolve([]);
                return;
            }

            fs.readFile(this.usersFile, 'utf8', (err, data) => {
                if (err) {
                    reject(err);
                    return;
                }

                const users = data.split('\n')
                    .filter(line => line.trim())
                    .map(line => {
                        const [username, password, expiration] = line.split(' ');
                        return { username, password, expiration };
                    });

                resolve(users);
            });
        });
    }

    // Verificar status do sistema SSH-PLUS
    async checkSystemStatus() {
        return new Promise((resolve) => {
            exec('systemctl is-active ssh', (error, stdout, stderr) => {
                const sshActive = stdout.trim() === 'active';
                
                exec('ps aux | grep -v grep | grep sshd', (error, stdout, stderr) => {
                    const sshProcesses = stdout ? stdout.split('\n').length - 1 : 0;
                    
                    resolve({
                        sshService: sshActive,
                        sshProcesses: sshProcesses,
                        systemReady: sshActive && sshProcesses > 0
                    });
                });
            });
        });
    }

    // Criar configuração completa para cliente
    async createVPNConfig(username, password, plano) {
        try {
            const serverInfo = await this.getServerInfo();
            
            const config = {
                servidor: {
                    ip: serverInfo.ip,
                    porta_ssh: serverInfo.sshPort,
                    hostname: serverInfo.hostname
                },
                usuario: {
                    login: username,
                    senha: password,
                    plano: plano.nome,
                    duracao: plano.duracao,
                    criado_em: new Date().toISOString(),
                    expira_em: new Date(Date.now() + (plano.duracao.includes('30') ? 30 : plano.duracao.includes('60') ? 60 : 90) * 24 * 60 * 60 * 1000).toISOString()
                },
                aplicativos: {
                    http_injector: {
                        payload: `GET / HTTP/1.1[crlf]Host: ${serverInfo.ip}[crlf]Upgrade: websocket[crlf][crlf]`,
                        proxy: `${serverInfo.ip}:8080`
                    },
                    http_custom: {
                        payload: `GET wss://mobilidade.cloud.caixa.gov.br/ HTTP/1.1[crlf]Host: ${serverInfo.ip}[crlf]Upgrade: websocket[crlf][crlf]`,
                        proxy: `${serverInfo.ip}:8080`
                    },
                    ssh_tunnel: {
                        host: serverInfo.ip,
                        porta: serverInfo.sshPort,
                        usuario: username,
                        senha: password
                    }
                }
            };

            return config;
        } catch (error) {
            console.error('Erro ao criar configuração VPN:', error);
            throw error;
        }
    }
}

module.exports = VPNManager;

