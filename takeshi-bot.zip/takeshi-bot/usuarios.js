const VPNManager = require('../vpn-manager');
const { OWNER_NUMBER } = require('../config');

exports.run = async (sock, message, args) => {
    const chatId = message.key.remoteJid;
    const userId = message.key.participant || message.key.remoteJid;
    const userNumber = userId.replace('@s.whatsapp.net', '');
    
    // Verificar se é o dono do bot
    if (userNumber !== OWNER_NUMBER) {
        await sock.sendMessage(chatId, { 
            text: "❌ Comando disponível apenas para o administrador." 
        });
        return;
    }

    const vpnManager = new VPNManager();
    
    try {
        if (!args[0]) {
            // Mostrar menu de opções
            let menuText = "👥 *GERENCIAMENTO DE USUÁRIOS VPN* 👥\n\n";
            menuText += "📋 *Comandos disponíveis:*\n\n";
            menuText += "• */usuarios listar* - Listar todos os usuários\n";
            menuText += "• */usuarios remover [username]* - Remover usuário\n";
            menuText += "• */usuarios status* - Status do sistema\n";
            menuText += "• */usuarios criar [dias]* - Criar usuário manual\n\n";
            menuText += "💡 *Exemplo:* /usuarios remover vpn123456";
            
            await sock.sendMessage(chatId, { text: menuText });
            return;
        }

        const acao = args[0].toLowerCase();

        switch (acao) {
            case 'listar':
                await listarUsuarios(sock, chatId, vpnManager);
                break;
                
            case 'remover':
                if (!args[1]) {
                    await sock.sendMessage(chatId, { 
                        text: "❌ Informe o nome do usuário!\nUso: */usuarios remover [username]*" 
                    });
                    return;
                }
                await removerUsuario(sock, chatId, vpnManager, args[1]);
                break;
                
            case 'status':
                await statusSistema(sock, chatId, vpnManager);
                break;
                
            case 'criar':
                const dias = args[1] ? parseInt(args[1]) : 30;
                await criarUsuarioManual(sock, chatId, vpnManager, dias);
                break;
                
            default:
                await sock.sendMessage(chatId, { 
                    text: "❌ Ação inválida! Use */usuarios* para ver as opções." 
                });
        }

    } catch (error) {
        console.error('Erro no comando usuarios:', error);
        await sock.sendMessage(chatId, { 
            text: "❌ Erro interno. Tente novamente mais tarde." 
        });
    }
};

async function listarUsuarios(sock, chatId, vpnManager) {
    try {
        await sock.sendMessage(chatId, { 
            text: "🔍 Carregando lista de usuários..." 
        });

        const usuarios = await vpnManager.listActiveUsers();
        
        if (usuarios.length === 0) {
            await sock.sendMessage(chatId, { 
                text: "📋 *LISTA DE USUÁRIOS*\n\n❌ Nenhum usuário encontrado." 
            });
            return;
        }

        let listaText = `📋 *LISTA DE USUÁRIOS* (${usuarios.length})\n\n`;
        
        usuarios.forEach((user, index) => {
            const expDate = new Date(user.expiration);
            const isExpired = expDate < new Date();
            const status = isExpired ? '❌ Expirado' : '✅ Ativo';
            
            listaText += `*${index + 1}.* ${user.username}\n`;
            listaText += `🔑 Senha: ${user.password}\n`;
            listaText += `📅 Expira: ${user.expiration}\n`;
            listaText += `📊 Status: ${status}\n\n`;
        });

        await sock.sendMessage(chatId, { text: listaText });

    } catch (error) {
        console.error('Erro ao listar usuários:', error);
        await sock.sendMessage(chatId, { 
            text: "❌ Erro ao carregar lista de usuários." 
        });
    }
}

async function removerUsuario(sock, chatId, vpnManager, username) {
    try {
        await sock.sendMessage(chatId, { 
            text: `🗑️ Removendo usuário ${username}...` 
        });

        const exists = await vpnManager.userExists(username);
        
        if (!exists) {
            await sock.sendMessage(chatId, { 
                text: `❌ Usuário ${username} não encontrado.` 
            });
            return;
        }

        await vpnManager.removeUser(username);
        
        await sock.sendMessage(chatId, { 
            text: `✅ *USUÁRIO REMOVIDO*\n\n👤 Usuário: ${username}\n🗑️ Removido com sucesso!` 
        });

    } catch (error) {
        console.error('Erro ao remover usuário:', error);
        await sock.sendMessage(chatId, { 
            text: `❌ Erro ao remover usuário ${username}.` 
        });
    }
}

async function statusSistema(sock, chatId, vpnManager) {
    try {
        await sock.sendMessage(chatId, { 
            text: "🔍 Verificando status do sistema..." 
        });

        const status = await vpnManager.checkSystemStatus();
        const serverInfo = await vpnManager.getServerInfo();
        const usuarios = await vpnManager.listActiveUsers();
        
        let statusText = `📊 *STATUS DO SISTEMA VPN* 📊\n\n`;
        statusText += `🌐 *Servidor:* ${serverInfo.ip}\n`;
        statusText += `🔌 *Porta SSH:* ${serverInfo.sshPort}\n\n`;
        statusText += `🔧 *Serviços:*\n`;
        statusText += `• SSH: ${status.sshService ? '✅ Ativo' : '❌ Inativo'}\n`;
        statusText += `• Processos SSH: ${status.sshProcesses}\n\n`;
        statusText += `👥 *Usuários:*\n`;
        statusText += `• Total: ${usuarios.length}\n`;
        
        const usuariosAtivos = usuarios.filter(u => new Date(u.expiration) > new Date());
        const usuariosExpirados = usuarios.filter(u => new Date(u.expiration) <= new Date());
        
        statusText += `• Ativos: ${usuariosAtivos.length}\n`;
        statusText += `• Expirados: ${usuariosExpirados.length}\n\n`;
        statusText += `🔄 *Sistema:* ${status.systemReady ? '✅ Operacional' : '⚠️ Verificar configuração'}`;

        await sock.sendMessage(chatId, { text: statusText });

    } catch (error) {
        console.error('Erro ao verificar status:', error);
        await sock.sendMessage(chatId, { 
            text: "❌ Erro ao verificar status do sistema." 
        });
    }
}

async function criarUsuarioManual(sock, chatId, vpnManager, dias) {
    try {
        await sock.sendMessage(chatId, { 
            text: `🔄 Criando usuário manual (${dias} dias)...` 
        });

        const username = vpnManager.generateUsername('admin');
        const password = vpnManager.generatePassword(10);
        
        const userResult = await vpnManager.createSSHUser(username, password, dias);
        
        if (userResult.created) {
            const serverInfo = await vpnManager.getServerInfo();
            
            let mensagem = `✅ *USUÁRIO CRIADO MANUALMENTE* ✅\n\n`;
            mensagem += `👤 *Usuário:* ${username}\n`;
            mensagem += `🔑 *Senha:* ${password}\n`;
            mensagem += `🌐 *Servidor:* ${serverInfo.ip}\n`;
            mensagem += `🔌 *Porta:* ${serverInfo.sshPort}\n`;
            mensagem += `📅 *Expira em:* ${userResult.expirationDate}\n`;
            mensagem += `⏰ *Duração:* ${dias} dias`;

            await sock.sendMessage(chatId, { text: mensagem });
        } else {
            throw new Error('Falha ao criar usuário');
        }

    } catch (error) {
        console.error('Erro ao criar usuário manual:', error);
        await sock.sendMessage(chatId, { 
            text: "❌ Erro ao criar usuário manual." 
        });
    }
}

exports.help = {
    name: "usuarios",
    description: "Gerenciar usuários VPN (apenas admin)",
    usage: "usuarios [listar|remover|status|criar] [parâmetros]"
};

