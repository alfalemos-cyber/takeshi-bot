const axios = require('axios');

// Configurações do Mercado Pago
const MERCADO_PAGO_CONFIG = {
    ACCESS_TOKEN: 'APP_USR-153110256233483-042622-5e61d8c4f515a3e4858a188558b7b725-1697276618',
    PUBLIC_KEY: 'APP_USR-412946cc-273e-4208-a32e-8391bceb3419',
    CLIENT_ID: '153110256233483',
    CLIENT_SECRET: 'U09K3LS1V2RCfFTeqjFbUm415xApHxWy',
    BASE_URL: 'https://api.mercadopago.com'
};

class MercadoPagoService {
    constructor() {
        this.accessToken = MERCADO_PAGO_CONFIG.ACCESS_TOKEN;
        this.baseURL = MERCADO_PAGO_CONFIG.BASE_URL;
    }

    // Criar pagamento PIX
    async createPixPayment(amount, description, externalReference) {
        try {
            const paymentData = {
                transaction_amount: amount,
                description: description,
                payment_method_id: 'pix',
                external_reference: externalReference,
                payer: {
                    email: 'cliente@email.com'
                }
            };

            const response = await axios.post(
                `${this.baseURL}/v1/payments`,
                paymentData,
                {
                    headers: {
                        'Authorization': `Bearer ${this.accessToken}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            return {
                success: true,
                payment_id: response.data.id,
                qr_code: response.data.point_of_interaction.transaction_data.qr_code,
                qr_code_base64: response.data.point_of_interaction.transaction_data.qr_code_base64,
                ticket_url: response.data.point_of_interaction.transaction_data.ticket_url,
                status: response.data.status
            };
        } catch (error) {
            console.error('Erro ao criar pagamento PIX:', error.response?.data || error.message);
            return {
                success: false,
                error: error.response?.data || error.message
            };
        }
    }

    // Verificar status do pagamento
    async checkPaymentStatus(paymentId) {
        try {
            const response = await axios.get(
                `${this.baseURL}/v1/payments/${paymentId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${this.accessToken}`
                    }
                }
            );

            return {
                success: true,
                status: response.data.status,
                status_detail: response.data.status_detail,
                external_reference: response.data.external_reference,
                transaction_amount: response.data.transaction_amount
            };
        } catch (error) {
            console.error('Erro ao verificar status do pagamento:', error.response?.data || error.message);
            return {
                success: false,
                error: error.response?.data || error.message
            };
        }
    }

    // Criar preferência de pagamento (para outros métodos)
    async createPreference(items, backUrls, externalReference) {
        try {
            const preferenceData = {
                items: items,
                back_urls: backUrls,
                external_reference: externalReference,
                auto_return: 'approved'
            };

            const response = await axios.post(
                `${this.baseURL}/checkout/preferences`,
                preferenceData,
                {
                    headers: {
                        'Authorization': `Bearer ${this.accessToken}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            return {
                success: true,
                preference_id: response.data.id,
                init_point: response.data.init_point,
                sandbox_init_point: response.data.sandbox_init_point
            };
        } catch (error) {
            console.error('Erro ao criar preferência:', error.response?.data || error.message);
            return {
                success: false,
                error: error.response?.data || error.message
            };
        }
    }
}

module.exports = MercadoPagoService;

